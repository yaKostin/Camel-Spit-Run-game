# Camel-Spit-Run-game
Runner HTML5 game with Camel hero

##Added
-scrolling background image;  
-running camel sprite (without animation);  
-score, fps, countdown interface elements;  
-changing track;  
-pause & unpase when change window focus;  
